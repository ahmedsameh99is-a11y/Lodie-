# Security Summary

**Reviewed Files**: 14
**Issues Resolved**: 8

### Issues Resolved
| Area | File | Line | What Was Happening | Impact | Status | How It Was Fixed |
|---|---|---|---|---|---|---|
| Cross-Origin State Requests | `server/middleware.ts`, `server/app.ts` | 160 | Cookie-authenticated mutating API endpoints did not enforce an origin / `Sec-Fetch-Site` browser boundary. | Medium | Fixed | Added `csrfOriginCheck` middleware on `/api` validating `Sec-Fetch-Site`, `Origin`, and `Referer` against the request host for cookie-authenticated mutations while allowing explicit `Bearer` API clients. |
| HTTPS Cookie Flags | `server/security.ts`, `server/routes/auth.ts` | 165 | Session cookies defaulted to `SameSite=Lax`, which breaks third-party iframe previews over HTTPS while still needing clean attributes locally. | Medium | Fixed | Made `setSessionCookie` and `clearSessionCookie` request-aware: HTTPS requests emit `HttpOnly; Secure; SameSite=None; Partitioned` while HTTP localhost keeps `HttpOnly; SameSite=Lax`. |
| Built-in Tool & Skill RBAC | `server/routes/mcp.ts`, `server/routes/skills.ts` | 194, 152 | Any signed-in user could toggle global built-in tools or mutate system built-in skills shared across the workspace. | Medium | Fixed | Added `requireDeveloper` on `PATCH /api/v1/mcp/builtin-tools/:id` and restricted built-in skill `PATCH` mutations to `developer` / `admin` roles. |
| Share Link Host Injection | `server/routes/chat.ts` | 269 | Share URL generation trusted arbitrary `Host` headers when `APP_URL` was unset. | Low | Fixed | Validated `req.get('host')` against a strict hostname regex (`^[a-z0-9.-]+(:\d+)?$/i`) and fell back to a relative `/?share=...` path when invalid. |
| Agent Step Cross-User Isolation | `server/routes/agents.ts` | 242, 420 | Several `agent_runs` and `agent_steps` queries omitted `AND user_id = ?` scoping alongside `run_id`. | Medium | Fixed | Added explicit `AND user_id = ?` (and `AND run_id = ?` on dependency lookup) across all agent run mutation and lookup statements. |
| Restore Query Parameterization & Re-index | `server/routes/settings.ts` | 194 | Dynamic table name interpolation existed inside helper SQL strings and restored content skipped knowledge indexing. | Low | Fixed | Replaced interpolated SQL string construction with a static `Record<RestorableTable, string>` lookup map and queued restored knowledge items for user-scoped RAG indexing. |
| Unbounded Rate-Limiter Map | `server/security.ts` | 355 | In-memory rate-limit counters could grow without bound under sustained key churn. | Low | Fixed | Added periodic stale-entry pruning and a 5,000-entry hard ceiling inside `createRateLimiter`. |
| Downloaded File Content Containment | `server/routes/projects.ts` | 195 | Project files lacked persistent binary storage and sandboxed download headers. | Low | Fixed | Added `GET /api/v1/projects/:id/files/:fileId/download` enforcing user ownership, path confinement, `Content-Security-Policy: sandbox`, and `X-Content-Type-Options: nosniff`. |

### Safeguards Verified
| Area | File | How It's Protected |
|---|---|---|
| API Keys & Secrets | `server/providers/index.ts`, `server/env.ts` | Provider credentials stay strictly in server-side `process.env` and never enter client bundles or responses. |
| Database Queries | `server/db.ts`, `server/routes/*.ts` | All SQL statements execute through parameterized `better-sqlite3` prepared queries. |
| File Path Confinement | `server/knowledge.ts`, `server/security.ts` | Uploaded binary files are normalized with `path.resolve` and confined under `DATA_DIR/uploads/<userId>/`. |
| Developer Allowlist Sync | `server/middleware.ts` | Cookie and Firebase token verification both check `DEVELOPER_ALLOWLIST_EMAILS` server-side before evaluating entitlements. |

## PoC Verification

### 1. Cross-Origin State-Changing Request Blocking (CSRF Guard)

#### Summary
| Field | Value |
|---|---|
| Issue Type | Missing Origin Validation on Cookie-Authenticated Mutations |
| Impact | Medium |
| Affected File | `server/middleware.ts:160` |
| Test Scenario | `POST /api/v1/settings/preferences` with a valid `loody_session` cookie and `Origin: https://evil.example` (or `Sec-Fetch-Site: cross-site`). |

#### How It Was Fixed
Added `csrfOriginCheck` in `server/middleware.ts` mounted before authentication on `/api` in `server/app.ts`, blocking cookie-authenticated mutating methods whose browser `Origin`, `Referer`, or `Sec-Fetch-Site` violates same-origin policy while allowing explicit `Authorization: Bearer` requests.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | `POST /api/v1/settings/preferences` enters Express `/api` middleware chain (`server/app.ts`). | Enters `csrfOriginCheck` |
| 2 | `csrfOriginCheck` verifies no `Bearer` token is present and inspects `Origin: https://evil.example` against `Host` / `X-Forwarded-Host`. | Host mismatch detected |
| 3 | Responds immediately with HTTP 403 and skips downstream route mutation. | **Handled Safely** |

#### Conclusion
**Fix Verified** - Cross-origin cookie-bearing mutation requests are rejected before reaching state-modifying handlers.

### 2. Global Built-in Tool & Built-in Skill RBAC Enforcement

#### Summary
| Field | Value |
|---|---|
| Issue Type | Missing Role Check on Shared Workspace Resources |
| Impact | Medium |
| Affected File | `server/routes/mcp.ts:194`, `server/routes/skills.ts:152` |
| Test Scenario | Authenticated standard user (`role: 'user'`) calls `PATCH /api/v1/mcp/builtin-tools/utc_clock` with `{ enabled: false }`. |

#### How It Was Fixed
Attached `requireDeveloper` middleware to `PATCH /api/v1/mcp/builtin-tools/:id` and enforced `role === 'developer' || role === 'admin'` whenever modifying a system built-in skill in `server/routes/skills.ts`.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | Session authenticates as standard account (`role: 'user'`) via `attachAuth`. | `req.authUser.role === 'user'` |
| 2 | `requireDeveloper` evaluates `(role !== 'developer' && role !== 'admin')`. | Access denied |
| 3 | Route returns HTTP 403 without modifying SQLite `builtin_tools`. | **Handled Safely** |

#### Conclusion
**Fix Verified** - Shared platform tools and built-in skills can only be toggled by developer or admin roles.

### 3. Project File Download Confinement & Cleanup

#### Summary
| Field | Value |
|---|---|
| Issue Type | Missing Download Isolation Headers & Orphaned Artifacts |
| Impact | Low |
| Affected File | `server/routes/projects.ts:195` |
| Test Scenario | Account B requests `GET /api/v1/projects/:id/files/:fileId/download` for Account A's project file; Account A deletes project. |

#### How It Was Fixed
Added ownership-scoped download serving through `resolveUserBinaryPath` with `Content-Security-Policy: sandbox` and `X-Content-Type-Options: nosniff`, plus cascade cleanup of disk binaries and `knowledge_chunks` on project/file deletion.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | Download query checks `WHERE pf.id = ? AND pf.project_id = ? AND pf.user_id = ?`. | Non-owner receives HTTP 404 |
| 2 | Owner response sets `Content-Security-Policy: sandbox` and `X-Content-Type-Options: nosniff`. | Inline script execution prevented |
| 3 | Project deletion calls `removeUserBinaryFile` and `deleteKnowledgeSourceChunks` for all project files. | **Handled Safely** |

#### Conclusion
**Fix Verified** - Cross-tenant downloads are blocked, inline rendering is sandboxed, and deletions purge disk binaries and RAG chunks.
