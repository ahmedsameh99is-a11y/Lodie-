import test from 'node:test';
import assert from 'node:assert/strict';
import { REQUIRED_BRANDED_MODEL_IDS } from './modelRegistry';
import {
  getAllMatrixRoutes,
  getCompatibilityRoutesForModel,
  MATRIX_UNSUPPORTED_NOTES,
  MODEL_COMPATIBILITY_MATRIX,
} from './providerMatrix';

test('compatibility matrix covers all 5 branded LOODY models with <=10 verified routes each', () => {
  for (const modelId of REQUIRED_BRANDED_MODEL_IDS) {
    const routes = getCompatibilityRoutesForModel(modelId);
    assert.ok(routes.length >= 9 && routes.length <= 10, `${modelId} has unexpected route count: ${routes.length}`);
    // Unique provider+upstream pairs per model
    const keys = new Set(routes.map((r) => `${r.provider}::${r.upstreamModelId}`));
    assert.equal(keys.size, routes.length, `Duplicate route detected in ${modelId}`);
  }
  assert.equal(Object.keys(MODEL_COMPATIBILITY_MATRIX).length, 5);
});

test('compatibility matrix never assigns retired github-models or text-only models to loody-vision-1', () => {
  const all = getAllMatrixRoutes();
  assert.equal(
    all.some((r) => r.provider === 'github-models'),
    false,
    'Retired github-models must not appear in active routes'
  );

  const visionRoutes = getCompatibilityRoutesForModel('loody-vision-1');
  for (const route of visionRoutes) {
    assert.equal(route.supportsVision, true, `Non-vision route ${route.id} found in loody-vision-1`);
    assert.notEqual(route.provider, 'groq', 'Groq text-only catalog must not appear in loody-vision-1');
  }

  // Cloudflare Llama 3.3 must keep exact 24K limit
  const cfFast = getCompatibilityRoutesForModel('sonic-3').find((r) => r.provider === 'cloudflare');
  assert.ok(cfFast);
  assert.equal(cfFast.contextLimit, 24_000);

  // Explicit unsupported/excluded documentation exists
  assert.ok(MATRIX_UNSUPPORTED_NOTES.some((n) => n.provider === 'github-models'));
  assert.ok(MATRIX_UNSUPPORTED_NOTES.some((n) => n.provider === 'cohere'));
  assert.ok(MATRIX_UNSUPPORTED_NOTES.some((n) => n.provider === 'groq'));
});
