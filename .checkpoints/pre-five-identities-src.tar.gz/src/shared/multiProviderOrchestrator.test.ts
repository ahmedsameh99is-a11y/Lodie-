import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CircuitBreakerRegistry,
  DeterministicResponseCache,
  detectPromptLanguage,
  executeWithMultiProviderFallback,
  planProviderRoutes,
  trimMessagesForContextBudget,
  type ProviderRuntimeAvailability,
} from './multiProviderOrchestrator';
import { getCompatibilityRoutesForModel } from './providerMatrix';

function makeAvailability(enabledProviders: string[]): Record<string, ProviderRuntimeAvailability> {
  const all = [
    'gemini', 'mistral', 'cohere', 'xai', 'ai21', 'groq', 'cerebras', 'sambanova',
    'together', 'fireworks', 'github-models', 'huggingface', 'cloudflare', 'nvidia',
    'deepinfra', 'openai-compatible', 'anthropic-compatible', 'hosted-oss', 'openrouter',
  ];
  const out: Record<string, ProviderRuntimeAvailability> = {};
  for (const p of all) {
    out[p] = {
      configured: enabledProviders.includes(p),
      retired: p === 'github-models',
      todaySpendUsd: 0,
      dailyBudgetUsd: 20,
      todayRequests: 0,
      dailyRequestCap: 1000,
    };
  }
  return out;
}

test('CircuitBreakerRegistry opens on consecutive failures, cools down to half_open, and recovers on success', () => {
  const cb = new CircuitBreakerRegistry({ failureThreshold: 3, cooldownMs: 5_000 });
  const t0 = 1_000_000;

  assert.equal(cb.canAttempt('groq', t0).allowed, true);
  cb.recordFailure('groq', 'provider_unavailable', '503', t0);
  cb.recordFailure('groq', 'rate_limit', '429', t0 + 100);
  assert.equal(cb.canAttempt('groq', t0 + 200).state, 'closed');

  // 3rd failure opens circuit
  cb.recordFailure('groq', 'latency', '504', t0 + 300);
  assert.equal(cb.canAttempt('groq', t0 + 400).allowed, false);
  assert.equal(cb.canAttempt('groq', t0 + 400).state, 'open');

  // After cooldown passes, transitions to half_open probe
  const probeCheck = cb.canAttempt('groq', t0 + 6_000);
  assert.equal(probeCheck.allowed, true);
  assert.equal(probeCheck.state, 'half_open');

  // Successful response closes circuit and records latency
  cb.recordSuccess('groq', 320, t0 + 6_100);
  const closed = cb.canAttempt('groq', t0 + 6_200);
  assert.equal(closed.allowed, true);
  assert.equal(closed.state, 'closed');
  assert.equal(cb.get('groq').consecutiveFailures, 0);
  assert.equal(cb.get('groq').avgLatencyMs, 320);

  // Immediate open on auth_error
  cb.recordFailure('mistral', 'auth_error', '401 invalid key', t0);
  assert.equal(cb.canAttempt('mistral', t0 + 10).allowed, false);
});

test('planProviderRoutes filters by context ceiling, vision modality, budgets, and circuit state', () => {
  const cb = new CircuitBreakerRegistry({ failureThreshold: 2, cooldownMs: 10_000 });
  const avail = makeAvailability(['cloudflare', 'groq', 'gemini', 'mistral']);
  // Exhaust daily budget on mistral
  avail.mistral.todaySpendUsd = avail.mistral.dailyBudgetUsd;

  // 25,000 input tokens must skip Cloudflare's 24,000 limit cleanly
  const largePlan = planProviderRoutes({
    brandedModelId: 'sonic-3',
    routes: getCompatibilityRoutesForModel('sonic-3'),
    providerStatus: avail,
    circuitBreaker: cb,
    hasImageAttachments: false,
    requiresStreaming: true,
    estimatedInputTokens: 25_000,
    intentMode: 'fast',
    promptLanguage: 'en',
  });

  assert.equal(largePlan.candidates.some((c) => c.route.provider === 'cloudflare'), false);
  assert.equal(largePlan.candidates.some((c) => c.route.provider === 'mistral'), false);
  assert.ok(largePlan.skipped.some((s) => s.provider === 'cloudflare' && s.reason.includes('context headroom')));
  assert.ok(largePlan.skipped.some((s) => s.provider === 'mistral' && s.reason.includes('budget')));
  assert.ok(largePlan.candidates.some((c) => c.route.provider === 'gemini'));
  assert.ok(largePlan.candidates.some((c) => c.route.provider === 'groq'));

  // Vision check skips text-only routes cleanly
  const visionPlan = planProviderRoutes({
    brandedModelId: 'loody-vision-1',
    routes: getCompatibilityRoutesForModel('loody-vision-1'),
    providerStatus: makeAvailability(['gemini', 'groq', 'cohere', 'mistral']),
    circuitBreaker: cb,
    hasImageAttachments: true,
    requiresStreaming: true,
    estimatedInputTokens: 500,
    intentMode: 'analysis',
    promptLanguage: detectPromptLanguage('حلل هذه الصورة من فضلك'),
  });
  assert.equal(detectPromptLanguage('حلل هذه الصورة من فضلك'), 'ar');
  assert.ok(visionPlan.candidates.length >= 3);
  assert.equal(visionPlan.candidates.every((c) => c.route.supportsVision), true);
});

test('trimMessagesForContextBudget preserves latest user prompt and drops oldest history', () => {
  const msgs = [
    { role: 'user' as const, content: 'A'.repeat(4000) },
    { role: 'assistant' as const, content: 'B'.repeat(4000) },
    { role: 'user' as const, content: 'Latest important question' },
  ];
  const trimmed = trimMessagesForContextBudget(msgs, 200, 1_500);
  assert.ok(trimmed.trimmedTurns >= 1);
  assert.equal(trimmed.messages[trimmed.messages.length - 1].content, 'Latest important question');
});

test('executeWithMultiProviderFallback fails over transparently, respects AbortSignal, and caps retries', async () => {
  const cb = new CircuitBreakerRegistry({ failureThreshold: 2, cooldownMs: 5_000 });
  const avail = makeAvailability(['gemini', 'groq', 'mistral']);
  const plan = planProviderRoutes({
    brandedModelId: 'sonic-3',
    routes: getCompatibilityRoutesForModel('sonic-3'),
    providerStatus: avail,
    circuitBreaker: cb,
    hasImageAttachments: false,
    requiresStreaming: true,
    estimatedInputTokens: 100,
    intentMode: 'fast',
    promptLanguage: 'en',
  });

  // First candidate fails with 429 rate_limit, second returns empty, third succeeds
  let calls = 0;
  const result = await executeWithMultiProviderFallback({
    candidates: plan.candidates,
    circuitBreaker: cb,
    maxRetries: 3,
    invoke: async (cand) => {
      calls++;
      if (calls === 1) {
        throw Object.assign(new Error('429 Rate limit reached'), { errorClass: 'rate_limit', retryable: true });
      }
      if (calls === 2) {
        return { emittedAnyChunk: false, latencyMs: 50 };
      }
      assert.ok(cand.route.provider);
      return { emittedAnyChunk: true, latencyMs: 120 };
    },
    extractErrorMeta: (err) => ({
      errorClass: ((err as { errorClass?: string }).errorClass as 'rate_limit') ?? 'provider_unavailable',
      retryable: true,
      message: (err as Error).message,
    }),
  });

  assert.equal(calls, 3);
  assert.equal(result.fallbackOccurred, true);
  assert.equal(result.attempts.length, 3);
  assert.equal(result.attempts[2].ok, true);

  // Abort stops immediately without fallback attempts
  const ac = new AbortController();
  ac.abort();
  await assert.rejects(
    executeWithMultiProviderFallback({
      candidates: plan.candidates,
      circuitBreaker: cb,
      signal: ac.signal,
      invoke: async () => ({ emittedAnyChunk: true }),
      extractErrorMeta: () => ({ errorClass: 'provider_unavailable', retryable: true, message: 'err' }),
    }),
    (err: unknown) => (err as { name?: string })?.name === 'AbortError'
  );
});

test('DeterministicResponseCache enforces TTL expiry cleanly', () => {
  const cache = new DeterministicResponseCache({ maxEntries: 10, ttlMs: 1_000 });
  cache.set(
    'k1',
    { text: 'OK', inputTokens: 5, outputTokens: 1, provider: 'gemini', upstreamModelId: 'gemini-3.1-flash-lite' },
    10_000
  );
  assert.equal(cache.get('k1', 10_500)?.text, 'OK');
  assert.equal(cache.get('k1', 11_100), null);
});
