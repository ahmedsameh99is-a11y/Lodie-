import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import test, { after, before } from 'node:test';
import type Database from 'better-sqlite3';
import type { Express } from 'express';
import type { BrandedModel, ProviderId } from '../src/shared/types';

let db: Database.Database;
let app: Express;
let tempDbPath = '';
let streamModelResponse: typeof import('./providers/index').streamModelResponse;
let testProviderConnection: typeof import('./providers/index').testProviderConnection;

const envBackup: Record<string, string | undefined> = {};
const managedEnvVars = [
  'OPENAI_API_KEY', 'OPENAI_BASE_URL',
  'ANTHROPIC_API_KEY', 'ANTHROPIC_BASE_URL',
  'MISTRAL_API_KEY', 'MISTRAL_BASE_URL',
  'COHERE_API_KEY', 'COHERE_BASE_URL',
  'XAI_API_KEY', 'XAI_BASE_URL',
  'AI21_API_KEY', 'AI21_BASE_URL',
  'GROQ_API_KEY', 'GROQ_BASE_URL',
  'CEREBRAS_API_KEY', 'CEREBRAS_BASE_URL',
  'SAMBANOVA_API_KEY', 'SAMBANOVA_BASE_URL',
  'TOGETHER_API_KEY', 'TOGETHER_BASE_URL',
  'FIREWORKS_API_KEY', 'FIREWORKS_BASE_URL',
  'GITHUB_TOKEN',
  'HUGGINGFACE_API_KEY', 'HUGGINGFACE_BASE_URL',
  'CLOUDFLARE_ACCOUNT_ID', 'CLOUDFLARE_API_TOKEN', 'CLOUDFLARE_BASE_URL',
  'NVIDIA_API_KEY', 'NVIDIA_BASE_URL',
  'DEEPINFRA_API_KEY', 'DEEPINFRA_BASE_URL',
  'OPENROUTER_API_KEY', 'OPENROUTER_BASE_URL',
  'GEMINI_API_KEY',
];

function clearProviderEnvs() {
  for (const key of managedEnvVars) {
    delete process.env[key];
  }
}

async function withLoopbackServer(
  handler: http.RequestListener,
  fn: (baseUrl: string) => Promise<void>
): Promise<void> {
  const srv = http.createServer(handler);
  await new Promise<void>((resolve) => srv.listen(0, '127.0.0.1', () => resolve()));
  const addr = srv.address() as { port: number };
  const url = `http://127.0.0.1:${addr.port}`;
  try {
    await fn(url);
  } finally {
    await new Promise<void>((resolve) => srv.close(() => resolve()));
  }
}

function makeModel(overrides: Partial<BrandedModel> = {}): BrandedModel {
  return {
    id: 'sonic-3',
    displayName: 'Sonic 3',
    tier: 'free',
    requiredPlan: 'free',
    provider: 'groq',
    upstreamModelId: 'llama-3.1-8b-instant',
    description: 'Test model',
    speedClass: 'Ultra-Fast',
    reasoningLevel: 'Standard',
    contextLimit: 128_000,
    inputModalities: ['text'],
    outputModalities: ['text'],
    supportsTools: true,
    supportsStreaming: true,
    pricingSummary: 'Test',
    availability: 'connected',
    availabilityReason: 'Test',
    lastTestedAt: null,
    ...overrides,
  };
}

before(async () => {
  for (const key of managedEnvVars) {
    envBackup[key] = process.env[key];
  }
  clearProviderEnvs();

  tempDbPath = path.join(os.tmpdir(), `loody-multiprovider-${process.pid}-${Date.now()}.db`);
  process.env.LOODY_DB_PATH = tempDbPath;

  const dbMod = await import('./db');
  db = dbMod.db;
  const provMod = await import('./providers/index');
  streamModelResponse = provMod.streamModelResponse;
  testProviderConnection = provMod.testProviderConnection;
  const appMod = await import('./app');
  app = appMod.createApiApp();
});

after(() => {
  for (const key of managedEnvVars) {
    const val = envBackup[key];
    if (val === undefined) delete process.env[key];
    else process.env[key] = val;
  }
  db.close();
  for (const ext of ['', '-wal', '-shm']) {
    fs.rmSync(`${tempDbPath}${ext}`, { force: true });
  }
});

test('All OpenAI-compatible new providers stream SSE, send expected auth headers, and handle vision payloads', async () => {
  const providerCases: Array<{
    provider: ProviderId;
    keyEnv: string;
    baseEnv: string;
    upstream: string;
    supportsVision: boolean;
  }> = [
    { provider: 'mistral', keyEnv: 'MISTRAL_API_KEY', baseEnv: 'MISTRAL_BASE_URL', upstream: 'pixtral-large-latest', supportsVision: true },
    { provider: 'xai', keyEnv: 'XAI_API_KEY', baseEnv: 'XAI_BASE_URL', upstream: 'grok-2-vision', supportsVision: true },
    { provider: 'ai21', keyEnv: 'AI21_API_KEY', baseEnv: 'AI21_BASE_URL', upstream: 'jamba-mini', supportsVision: false },
    { provider: 'groq', keyEnv: 'GROQ_API_KEY', baseEnv: 'GROQ_BASE_URL', upstream: 'meta-llama/llama-4-scout-17b-16e-instruct', supportsVision: true },
    { provider: 'cerebras', keyEnv: 'CEREBRAS_API_KEY', baseEnv: 'CEREBRAS_BASE_URL', upstream: 'llama3.1-8b', supportsVision: false },
    { provider: 'sambanova', keyEnv: 'SAMBANOVA_API_KEY', baseEnv: 'SAMBANOVA_BASE_URL', upstream: 'Meta-Llama-3.3-70B-Instruct', supportsVision: false },
    { provider: 'together', keyEnv: 'TOGETHER_API_KEY', baseEnv: 'TOGETHER_BASE_URL', upstream: 'Qwen/Qwen3.5-9B', supportsVision: true },
    { provider: 'fireworks', keyEnv: 'FIREWORKS_API_KEY', baseEnv: 'FIREWORKS_BASE_URL', upstream: 'accounts/fireworks/models/deepseek-v3', supportsVision: false },
    { provider: 'huggingface', keyEnv: 'HUGGINGFACE_API_KEY', baseEnv: 'HUGGINGFACE_BASE_URL', upstream: 'meta-llama/Llama-3.1-8B-Instruct', supportsVision: false },
    { provider: 'nvidia', keyEnv: 'NVIDIA_API_KEY', baseEnv: 'NVIDIA_BASE_URL', upstream: 'meta/llama-3.2-11b-vision-instruct', supportsVision: true },
    { provider: 'deepinfra', keyEnv: 'DEEPINFRA_API_KEY', baseEnv: 'DEEPINFRA_BASE_URL', upstream: 'meta-llama/Llama-3.3-70B-Instruct', supportsVision: false },
    { provider: 'openrouter', keyEnv: 'OPENROUTER_API_KEY', baseEnv: 'OPENROUTER_BASE_URL', upstream: 'meta-llama/llama-3.3-70b-instruct', supportsVision: true },
  ];

  for (const tc of providerCases) {
    let seenAuth = '';
    let seenBody: Record<string, any> | null = null;
    let seenOpenRouterTitle = '';

    await withLoopbackServer((req, res) => {
      seenAuth = String(req.headers.authorization ?? '');
      seenOpenRouterTitle = String(req.headers['x-openrouter-title'] ?? '');
      let raw = '';
      req.on('data', (c) => (raw += c));
      req.on('end', () => {
        seenBody = JSON.parse(raw);
        res.writeHead(200, { 'Content-Type': 'text/event-stream' });
        res.write(`data: {"choices":[{"delta":{"content":"Ack ${tc.provider}"}}]}\n\n`);
        res.write('data: {"choices":[],"usage":{"prompt_tokens":11,"completion_tokens":3}}\n\n');
        res.end('data: [DONE]\n\n');
      });
    }, async (baseUrl) => {
      process.env[tc.keyEnv] = `key-${tc.provider}`;
      process.env[tc.baseEnv] = baseUrl;
      try {
        let output = '';
        await streamModelResponse({
          model: makeModel({
            id: tc.supportsVision ? 'loody-vision-1' : 'sonic-3',
            provider: tc.provider,
            upstreamModelId: tc.upstream,
            inputModalities: tc.supportsVision ? ['text', 'image'] : ['text'],
          }),
          systemInstruction: 'System prompt',
          messages: [
            {
              role: 'user',
              content: 'Analyze',
              attachments: tc.supportsVision
                ? [{ mimeType: 'image/png', dataBase64: 'AAAA', name: 'img.png', sizeBytes: 4 }]
                : undefined,
            },
          ],
          callbacks: {
            onChunk: (t) => {
              output += t;
            },
          },
        });
        assert.equal(output, `Ack ${tc.provider}`);
        assert.equal(seenAuth, `Bearer key-${tc.provider}`);
        assert.equal(seenBody?.model, tc.upstream);
        if (tc.supportsVision) {
          const userMsg = seenBody?.messages?.find((m: any) => m.role === 'user');
          assert.ok(Array.isArray(userMsg?.content));
          assert.equal(userMsg.content[1]?.image_url?.url, 'data:image/png;base64,AAAA');
        }
        if (tc.provider === 'openrouter') {
          assert.equal(seenOpenRouterTitle, 'LOODY AI Workspace');
        }
      } finally {
        delete process.env[tc.keyEnv];
        delete process.env[tc.baseEnv];
      }
    });
  }
});

test('Cohere v2 native SSE streaming, Cloudflare dual-credential check, Anthropic prompt caching, and retired GitHub Models work accurately', async () => {
  // 1. Cohere /v2/chat SSE
  await withLoopbackServer((req, res) => {
    assert.equal(req.url, '/v2/chat');
    assert.equal(req.headers.authorization, 'Bearer test-cohere-key');
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    res.write('event: content-delta\ndata: {"type":"content-delta","delta":{"message":{"content":{"text":"مرحبا "}}}}\n\n');
    res.write('event: content-delta\ndata: {"type":"content-delta","delta":{"message":{"content":{"text":"Cohere"}}}}\n\n');
    res.write('event: message-end\ndata: {"type":"message-end","delta":{"usage":{"tokens":{"input_tokens":18,"output_tokens":7}}}}\n\n');
    res.end();
  }, async (baseUrl) => {
    process.env.COHERE_API_KEY = 'test-cohere-key';
    process.env.COHERE_BASE_URL = baseUrl;
    try {
      let text = '';
      let usage: any;
      await streamModelResponse({
        model: makeModel({ id: 'fables-5.3', provider: 'cohere', upstreamModelId: 'command-a' }),
        systemInstruction: 'Be helpful in Arabic',
        messages: [{ role: 'user', content: 'مرحبا' }],
        callbacks: {
          onChunk: (c) => (text += c),
          onUsage: (u) => (usage = u),
        },
      });
      assert.equal(text, 'مرحبا Cohere');
      assert.deepEqual(usage, { inputTokens: 18, outputTokens: 7, cachedTokens: 0 });
    } finally {
      delete process.env.COHERE_API_KEY;
      delete process.env.COHERE_BASE_URL;
    }
  });

  // 2. Cloudflare Workers AI requires BOTH CLOUDFLARE_ACCOUNT_ID and CLOUDFLARE_API_TOKEN
  process.env.CLOUDFLARE_API_TOKEN = 'cf-only-token';
  const cfMissingAcc = await testProviderConnection(
    makeModel({ id: 'sonic-3', provider: 'cloudflare', upstreamModelId: '@cf/meta/llama-3.3-70b-instruct-fp8-fast' })
  );
  assert.equal(cfMissingAcc.ok, false);
  assert.equal(cfMissingAcc.healthStatus, 'awaiting_config');
  assert.match(cfMissingAcc.message, /CLOUDFLARE_ACCOUNT_ID/);
  delete process.env.CLOUDFLARE_API_TOKEN;

  await withLoopbackServer((req, res) => {
    assert.equal(req.headers.authorization, 'Bearer cf-tok');
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    res.write('data: {"choices":[{"delta":{"content":"CF-OK"}}]}\n\n');
    res.end('data: [DONE]\n\n');
  }, async (baseUrl) => {
    process.env.CLOUDFLARE_ACCOUNT_ID = 'acct_12345678';
    process.env.CLOUDFLARE_API_TOKEN = 'cf-tok';
    process.env.CLOUDFLARE_BASE_URL = baseUrl;
    try {
      let text = '';
      await streamModelResponse({
        model: makeModel({ id: 'sonic-3', provider: 'cloudflare', upstreamModelId: '@cf/meta/llama-3.3-70b-instruct-fp8-fast' }),
        messages: [{ role: 'user', content: 'Hi' }],
        callbacks: { onChunk: (c) => (text += c) },
      });
      assert.equal(text, 'CF-OK');
    } finally {
      delete process.env.CLOUDFLARE_ACCOUNT_ID;
      delete process.env.CLOUDFLARE_API_TOKEN;
      delete process.env.CLOUDFLARE_BASE_URL;
    }
  });

  // 3. Anthropic ephemeral cache_control for long system prompt
  let capturedAnthropicBody: Record<string, any> | null = null;
  await withLoopbackServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      capturedAnthropicBody = JSON.parse(raw);
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"type":"text_delta","text":"CachedOK"}}\n\n');
      res.end();
    });
  }, async (baseUrl) => {
    process.env.ANTHROPIC_API_KEY = 'anth-key';
    process.env.ANTHROPIC_BASE_URL = baseUrl;
    try {
      let text = '';
      await streamModelResponse({
        model: makeModel({ id: 'lodie-5.5', provider: 'anthropic-compatible', upstreamModelId: 'claude-sonnet-4-5' }),
        systemInstruction: 'X'.repeat(1200),
        messages: [{ role: 'user', content: 'Hi' }],
        callbacks: { onChunk: (c) => (text += c) },
      });
      assert.equal(text, 'CachedOK');
      assert.ok(Array.isArray(capturedAnthropicBody?.system));
      assert.deepEqual(capturedAnthropicBody?.system?.[0]?.cache_control, { type: 'ephemeral' });
    } finally {
      delete process.env.ANTHROPIC_API_KEY;
      delete process.env.ANTHROPIC_BASE_URL;
    }
  });

  // 4. GitHub Models retired July 30, 2026
  process.env.GITHUB_TOKEN = 'ghp_dummy';
  const ghProbe = await testProviderConnection(
    makeModel({ id: 'sonic-3', provider: 'github-models', upstreamModelId: 'gpt-4.1-mini' })
  );
  assert.equal(ghProbe.ok, false);
  assert.equal(ghProbe.errorClass, 'configuration_error');
  assert.match(ghProbe.message, /retired/i);
  delete process.env.GITHUB_TOKEN;
});

test('End-to-end /chat/stream failover preserves LOODY branded model, supports Arabic RTL, concurrency, cancellation, and blocks secret leaks', async () => {
  const srv = http.createServer(app);
  await new Promise<void>((resolve) => srv.listen(0, '127.0.0.1', () => resolve()));
  const port = (srv.address() as { port: number }).port;
  const apiUrl = `http://127.0.0.1:${port}`;

  // Loopback primary (Groq returns 429 rate limit) and backup (Mistral responds cleanly in Arabic & English)
  let groqHits = 0;
  let mistralHits = 0;

  try {
    await withLoopbackServer((_req, res) => {
      groqHits++;
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'Rate limit exceeded' } }));
    }, async (groqBase) => {
      await withLoopbackServer((req, res) => {
        mistralHits++;
        let raw = '';
        req.on('data', (c) => (raw += c));
        req.on('end', () => {
          const parsed = JSON.parse(raw);
          const lastUser = String(parsed.messages?.[parsed.messages.length - 1]?.content ?? '');
          if (lastUser.includes('Slow cancel test')) {
            res.writeHead(200, { 'Content-Type': 'text/event-stream' });
            res.write('data: {"choices":[{"delta":{"content":"Partial "}}]}\n\n');
            const timer = setTimeout(() => {
              if (!res.writableEnded) {
                res.write('data: {"choices":[{"delta":{"content":"End"}}]}\n\n');
                res.end('data: [DONE]\n\n');
              }
            }, 350);
            req.on('close', () => clearTimeout(timer));
            return;
          }
          const reply = /[\u0600-\u06FF]/.test(lastUser)
            ? 'مرحباً! تم التنفيذ بنجاح.'
            : 'Hello from fallback provider!';
          res.writeHead(200, { 'Content-Type': 'text/event-stream' });
          res.write(`data: {"choices":[{"delta":{"content":${JSON.stringify(reply)}}}]}\n\n`);
          res.end('data: [DONE]\n\n');
        });
      }, async (mistralBase) => {
        // Configure sonic-3 primary in registry to groq, plus MISTRAL_API_KEY as fallback
        db.prepare("UPDATE model_registry SET provider = 'groq', upstream_model_id = 'llama-3.1-8b-instant', availability = 'operational' WHERE id = 'sonic-3'").run();
        process.env.GROQ_API_KEY = 'secret-groq-do-not-leak';
        process.env.GROQ_BASE_URL = groqBase;
        process.env.MISTRAL_API_KEY = 'secret-mistral-do-not-leak';
        process.env.MISTRAL_BASE_URL = mistralBase;

        try {
          // 1. Register user
          const regRes = await fetch(`${apiUrl}/api/v1/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: `multi-${Date.now()}@loody.test`,
              password: 'TestPassword123!',
              displayName: 'Multi Tester',
            }),
          });
          assert.equal(regRes.status, 201);
          const cookie = regRes.headers.get('set-cookie')?.split(';')[0] ?? '';
          assert.ok(cookie);

          // 2. Check /models/matrix never leaks secrets & unauthorized blocks /providers/:id/test
          const matrixRes = await fetch(`${apiUrl}/api/v1/models/matrix`, {
            headers: { Cookie: cookie },
          });
          assert.equal(matrixRes.status, 200);
          const matrixText = await matrixRes.text();
          assert.equal(matrixText.includes('secret-groq-do-not-leak'), false);
          assert.equal(matrixText.includes('secret-mistral-do-not-leak'), false);

          const devBlocked = await fetch(`${apiUrl}/api/v1/models/providers/groq/test`, {
            method: 'POST',
            headers: { Cookie: cookie },
          });
          assert.equal(devBlocked.status, 403);

          // 3. Streaming chat triggers automatic failover groq (429) -> mistral (200) while preserving sonic-3!
          const chatRes = await fetch(`${apiUrl}/api/v1/chat/stream`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Cookie: cookie },
            body: JSON.stringify({
              modelId: 'sonic-3',
              prompt: 'اكتب لي ملخصاً سريعاً بالعربية',
              orchestrationMode: 'fast',
            }),
          });
          assert.equal(chatRes.status, 200);
          const sseText = await chatRes.text();
          assert.ok(groqHits >= 1);
          assert.ok(mistralHits >= 1);
          assert.match(sseText, /مرحباً! تم التنفيذ بنجاح\./);
          assert.match(sseText, /"modelId":"sonic-3"/);
          assert.match(sseText, /event: done/);

          // 4. Concurrent follow-up English & coding requests succeed cleanly
          const [r1, r2] = await Promise.all([
            fetch(`${apiUrl}/api/v1/chat/stream`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Cookie: cookie },
              body: JSON.stringify({ modelId: 'sonic-3', prompt: 'Explain binary search in TypeScript', orchestrationMode: 'coding' }),
            }),
            fetch(`${apiUrl}/api/v1/chat/stream`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Cookie: cookie },
              body: JSON.stringify({ modelId: 'sonic-3', prompt: 'Hello test', orchestrationMode: 'fast' }),
            }),
          ]);
          assert.equal(r1.status, 200);
          assert.equal(r2.status, 200);
          const t1 = await r1.text();
          const t2 = await r2.text();
          assert.match(t1, /Hello from fallback provider!/);
          assert.match(t2, /Hello from fallback provider!/);

          // 5. Mid-stream AbortController cancellation terminates cleanly without crashing server
          const ac = new AbortController();
          const cancelResp = await fetch(`${apiUrl}/api/v1/chat/stream`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Cookie: cookie },
            signal: ac.signal,
            body: JSON.stringify({ modelId: 'sonic-3', prompt: 'Slow cancel test', orchestrationMode: 'fast' }),
          });
          assert.equal(cancelResp.status, 200);
          setTimeout(() => ac.abort(), 30);
          await assert.rejects(
            cancelResp.text(),
            (e: unknown) => (e as { name?: string })?.name === 'AbortError'
          );
        } finally {
          clearProviderEnvs();
        }
      });
    });
  } finally {
    await new Promise<void>((resolve) => srv.close(() => resolve()));
  }
});
